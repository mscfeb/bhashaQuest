import { Flame, LockKeyhole, Sparkles, Star } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Brand from "../components/ui/Brand";
import Button from "../components/ui/Button";

function GoogleMark() {
  return (
    <span className="grid size-5 place-items-center rounded-full bg-white text-sm font-black text-[#4285F4]">
      G
    </span>
  );
}

export default function LoginPage() {
  const navigate = useNavigate();
  return (
    <div className="flex min-h-screen flex-col bg-cream">
      <header className="p-5 sm:p-8">
        <Brand />
      </header>
      <main className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-6 pb-12">
        <div className="mb-8 flex justify-center">
          <div className="relative grid size-36 place-items-center rounded-[2.5rem] bg-sage">
            <div className="grid size-24 place-items-center rounded-[2rem] bg-forest text-white shadow-xl shadow-green-950/15">
              <Sparkles size={45} strokeWidth={1.6} />
            </div>
            <span className="absolute -right-2 top-2 grid size-12 place-items-center rounded-2xl bg-gold text-[#4D3B16]">
              <Flame size={26} />
            </span>
            <span className="absolute -bottom-2 -left-2 grid size-10 place-items-center rounded-xl bg-peach text-[#7D5140]">
              <Star size={21} />
            </span>
          </div>
        </div>
        <div className="mb-8 text-center">
          <p className="mb-3 text-xs font-black uppercase tracking-[0.2em] text-[#65806A]">
            Your daily language adventure
          </p>
          <h1 className="text-4xl font-black leading-[1.12] tracking-tight sm:text-5xl">
            A little practice.
            <br />
            <span className="text-[#56805A]">A lot of progress.</span>
          </h1>
          <p className="mx-auto mt-4 max-w-xs text-sm leading-6 text-muted">
            Speak a little every day. Build confidence, grow your streak, and
            make every word count.
          </p>
        </div>
        <Button className="w-full" onClick={() => navigate("/dashboard")}>
          <GoogleMark /> Continue with Google
        </Button>
        <p className="mt-3 text-center text-xs leading-5 text-muted">
          Preview mode: real Google authentication will be connected next.
        </p>
        <div className="mt-9 flex items-center justify-center gap-2 text-xs font-medium text-muted">
          <LockKeyhole size={14} /> Your learning journey, your pace.
        </div>
      </main>
    </div>
  );
}
