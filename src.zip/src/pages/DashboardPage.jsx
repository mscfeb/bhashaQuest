
import { useEffect, useState } from "react";
import {
  Flame,
  Star,
  Trophy,
  Zap,
  Check,
  Sparkles,
  ArrowRight,
  RefreshCw,
} from "lucide-react";

import AppShell from "../components/layout/AppShell";
import Button from "../components/ui/Button";
import StatCard from "../components/ui/StatCard";
import LanguageSelect from "../components/challenge/LanguageSelect";
import { getTodayChallenge, getTodayProgress } from "../services/api";
import { demoProgress } from "../data/demoData";

export default function DashboardPage() {
  const [language, setLanguage] = useState("hi");
  const [challenge, setChallenge] = useState(null);
  const [progress, setProgress] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function loadDashboard() {
      setLoading(true);
      setError("");

      try {
        const userId = import.meta.env.VITE_DEV_USER_ID;

        const [challengeResult, progressResult] = await Promise.all([
          getTodayChallenge(language),
          userId
            ? getTodayProgress(userId)
            : Promise.resolve(null),
        ]);

        if (cancelled) return;

        setChallenge(challengeResult);
        setProgress(progressResult);
      } catch (err) {
        if (!cancelled) {
          setError(
            err.message || "Unable to load your daily quest."
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    loadDashboard();

    return () => {
      cancelled = true;
    };
  }, [language]);

  // Temporary fallback until the backend response fields are confirmed.
  const stats = progress ?? demoProgress;

  const streak = stats.streak ?? 0;
  const totalXp = stats.totalXp ?? stats.total_xp ?? 0;
  const challengesWon =
    stats.challengesWon ?? stats.challenges_won ?? 0;
  const bestScore = stats.bestScore ?? stats.best_score ?? 0;

  const words = Array.isArray(challenge?.words)
    ? challenge.words
    : [];

  const challengeTitle =
    challenge?.topic || "Your daily quest";

  const getWordText = (word) =>
    word.englishWord ??
    word.english_word ??
    word.word ??
    word.english ??
    "";

  return (
    <AppShell>
      {/* Header */}
      <div className="flex items-center justify-between gap-3 pt-3">
        <div>
          <p className="text-sm font-medium text-muted">
            Your daily adventure
          </p>
          <h1 className="mt-1 text-3xl font-black tracking-tight sm:text-4xl">
            Hey, learner! 👋
          </h1>
        </div>

        <div className="grid size-12 shrink-0 place-items-center rounded-full border-2 border-white bg-sage text-lg font-black text-forest shadow-sm">
          B
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div
          className="mt-5 flex items-center gap-3 rounded-2xl border border-line bg-white p-4 text-sm text-muted"
          role="status"
        >
          <RefreshCw size={18} className="animate-spin" />
          Loading your daily quest...
        </div>
      )}

      {/* API error */}
      {error && (
        <div
          className="mt-5 rounded-2xl border border-red-200 bg-red-50 p-4"
          role="alert"
        >
          <p className="font-bold text-red-800">
            Couldn't load your dashboard
          </p>
          <p className="mt-1 text-sm text-red-700">
            {error}
          </p>
          <p className="mt-2 text-xs text-red-700">
            Check that FastAPI is running and that the API URL and
            CORS settings are correct.
          </p>
        </div>
      )}

      {/* Learning streak */}
      <section className="mt-6 rounded-[2rem] bg-forest p-5 text-white shadow-xl shadow-green-950/10 sm:p-7">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold text-sage">
              <Flame size={19} className="text-gold" />
              YOUR LEARNING STREAK
            </div>

            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-5xl font-black">{streak}</span>
              <span className="text-lg font-bold">days</span>
            </div>

            <p className="mt-2 text-sm text-sage">
              You're building a great habit!
            </p>
          </div>

          <div className="grid size-16 place-items-center rounded-3xl bg-white/10">
            <Flame size={39} className="text-gold" />
          </div>
        </div>

        <div className="mt-6 grid grid-cols-7 gap-1.5">
          {["M", "T", "W", "T", "F", "S", "S"].map(
            (day, index) => {
              const active = index < Math.min(streak, 7);

              return (
                <div key={`${day}-${index}`} className="text-center">
                  <div
                    className={`mx-auto grid size-9 place-items-center rounded-full ${
                      active
                        ? "bg-gold text-[#3A3019]"
                        : "bg-white/10 text-white/60"
                    }`}
                  >
                    {active ? (
                      <Check size={17} strokeWidth={3} />
                    ) : (
                      <span className="text-xs">{day}</span>
                    )}
                  </div>

                  <p className="mt-2 text-[10px] font-bold text-white/65">
                    {day}
                  </p>
                </div>
              );
            }
          )}
        </div>
      </section>

      {/* Progress statistics */}
      <section className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        <StatCard
          icon={<Zap size={21} />}
          label="Total XP"
          value={totalXp}
          detail="Keep collecting!"
          color="bg-[#FFF0C8] text-[#A56B0A]"
        />

        <StatCard
          icon={<Trophy size={21} />}
          label="Challenges won"
          value={challengesWon}
          detail="You're on a roll"
        />

        <div className="col-span-2 sm:col-span-1">
          <StatCard
            icon={<Star size={21} />}
            label="Best score"
            value={`${bestScore}/10`}
            detail="Your personal best"
            color="bg-peach text-[#8A5946]"
          />
        </div>
      </section>

      {/* Daily challenge */}
      <section className="mt-8">
        <div className="mb-3 flex items-center justify-between gap-2">
          <h2 className="text-lg font-black">
            Ready for today?
          </h2>

          <span className="rounded-full bg-sage px-3 py-1 text-xs font-bold text-forest">
            {words.length || 3} words · 2 tries
          </span>
        </div>

        <div className="rounded-[2rem] border border-line bg-white p-5 sm:p-7">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[#FFF0C8] px-3 py-1.5 text-xs font-bold text-[#91641B]">
            <Sparkles size={14} />
            DAILY QUEST
          </span>

          <h3 className="mt-4 text-2xl font-black">
            {challengeTitle}
          </h3>

          <p className="mt-2 text-sm leading-6 text-muted">
            Use three words in one spoken sentence. Your next 10 XP
            is waiting.
          </p>

          {/* Challenge words from the API */}
          {words.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2">
              {words.map((word, index) => (
                <span
                  key={word.id ?? word.position ?? index}
                  className="rounded-xl bg-sage px-3 py-2 text-sm font-bold text-forest"
                >
                  {getWordText(word) || `Word ${index + 1}`}
                </span>
              ))}
            </div>
          )}

          {!loading && !error && !challenge && (
            <p className="mt-3 text-sm text-muted">
              No challenge data is available yet.
            </p>
          )}

          <label
            htmlFor="learning-language"
            className="mt-5 block text-xs font-bold text-muted"
          >
            I'M PRACTISING
          </label>

          <LanguageSelect
            value={language}
            onChange={setLanguage}
          />

          <div className="mt-4 flex items-center justify-between gap-3 rounded-2xl bg-cream p-3.5">
            <div>
              <p className="text-sm font-bold">Today's reward</p>
              <p className="mt-1 text-xs text-muted">
                Complete the challenge
              </p>
            </div>

            <span className="flex shrink-0 items-center gap-1 rounded-full bg-[#FFF0C8] px-3 py-2 text-sm font-black text-[#8A5D0D]">
              <Zap size={15} />
              +10 XP
            </span>
          </div>

          <Button
            to={`/challenge?language=${language}`}
            className="mt-5 w-full"
          >
            Start today's quest
            <ArrowRight size={18} />
          </Button>
        </div>
      </section>

      <p className="mt-5 text-center text-xs text-muted-light">
        One small step today. A more confident you tomorrow.
      </p>
    </AppShell>
  );
}
