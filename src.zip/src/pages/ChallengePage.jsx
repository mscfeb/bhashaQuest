
import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, Link, useSearchParams } from "react-router-dom";
import {
  ArrowLeft,
  CircleHelp,
  Mic,
  Check,
  Zap,
  LoaderCircle,
  Square,
  AlertCircle,
  RefreshCw,
} from "lucide-react";

import AppShell from "../components/layout/AppShell";
import Button from "../components/ui/Button";
import WordCard from "../components/challenge/WordCard";
import LanguageSelect, {
  languages,
} from "../components/challenge/LanguageSelect";

import {
  getTodayChallenge,
  getTodayProgress,
  submitAudio,
} from "../services/api";

export default function ChallengePage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const requestedLanguage = searchParams.get("language");

  const [language, setLanguage] = useState(
    languages.some((item) => item.code === requestedLanguage)
      ? requestedLanguage
      : "hi"
  );

  const [challenge, setChallenge] = useState(null);
  const [loadingChallenge, setLoadingChallenge] = useState(true);
  const [challengeError, setChallengeError] = useState("");

  const [recording, setRecording] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [recordingError, setRecordingError] = useState("");
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [attemptsRemaining, setAttemptsRemaining] = useState(2);

  const mediaRecorderRef = useRef(null);
  const streamRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);
  const recordingSecondsRef = useRef(0);
  const recordingSessionRef = useRef(0);
  const mountedRef = useRef(true);

  const userId = import.meta.env.VITE_DEV_USER_ID;

  const words = Array.isArray(challenge?.words)
    ? challenge.words
    : [];

  const challengeId = challenge?.id;

  // Load the challenge whenever the selected language changes.
  useEffect(() => {
    let cancelled = false;

    async function loadChallenge() {
      setLoadingChallenge(true);
      setChallengeError("");
      setChallenge(null);
      setRecordingError("");

      try {
        const data = await getTodayChallenge(language);

        if (!cancelled) {
          setChallenge(data);
        }
      } catch (error) {
        if (!cancelled) {
          setChallengeError(
            error.message || "Unable to load today's challenge."
          );
        }
      } finally {
        if (!cancelled) {
          setLoadingChallenge(false);
        }
      }
    }

    loadChallenge();

    return () => {
      cancelled = true;
    };
  }, [language]);

  // Stop any active microphone when the page unmounts.
  useEffect(() => {
    mountedRef.current = true;

    return () => {
      mountedRef.current = false;
      recordingSessionRef.current += 1;

      if (timerRef.current) {
        clearInterval(timerRef.current);
      }

      const recorder = mediaRecorderRef.current;

      if (recorder && recorder.state !== "inactive") {
        recorder.onstop = null;
        recorder.stop();
      }

      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  const stopMicrophone = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    mediaRecorderRef.current = null;

    setRecording(false);
  }, []);

  function getSupportedMimeType() {
    if (typeof MediaRecorder === "undefined") {
      return "";
    }

    const types = [
      "audio/webm;codecs=opus",
      "audio/webm",
      "audio/mp4",
    ];

    return types.find((type) => MediaRecorder.isTypeSupported(type)) || "";
  }

  async function startRecording() {
    setRecordingError("");

    if (!challengeId) {
      setRecordingError("Today's challenge is not ready yet.");
      return;
    }

    if (!userId) {
      setRecordingError(
        "The development user ID is missing. Set VITE_DEV_USER_ID in your frontend .env file."
      );
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      setRecordingError(
        "Microphone access is unavailable. Use localhost or HTTPS in a supported browser."
      );
      return;
    }

    if (typeof MediaRecorder === "undefined") {
      setRecordingError(
        "Audio recording is not supported by this browser."
      );
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
      });

      if (!mountedRef.current) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }

      const mimeType = getSupportedMimeType();

      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);

      const session = ++recordingSessionRef.current;

      streamRef.current = stream;
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];
      recordingSecondsRef.current = 0;
      setRecordingSeconds(0);

      recorder.ondataavailable = (event) => {
        if (event.data?.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      recorder.onerror = () => {
        if (mountedRef.current) {
          setRecordingError("An error occurred while recording audio.");
        }
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());

        if (streamRef.current === stream) {
          streamRef.current = null;
        }

        if (mediaRecorderRef.current === recorder) {
          mediaRecorderRef.current = null;
        }

        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }

        if (
          !mountedRef.current ||
          session !== recordingSessionRef.current
        ) {
          return;
        }

        const audioType =
          recorder.mimeType || mimeType || "audio/webm";

        const audio = new Blob(chunksRef.current, {
          type: audioType,
        });

        chunksRef.current = [];

        if (!audio.size) {
          setRecordingError(
            "No audio was captured. Please try recording again."
          );
          return;
        }

        setSubmitting(true);
        setRecordingError("");

        try {
          // Refresh progress to estimate the current attempts remaining.
          // The submission endpoint remains authoritative.
          let progressData = null;

          try {
            progressData = await getTodayProgress(userId);
          } catch {
            // Progress is optional here; still submit the recording.
          }

          const result = await submitAudio({
            challengeId,
            language,
            userId,
            audio,
          });

          if (!mountedRef.current) return;

          navigate("/results", {
            state: {
              result,
              challenge,
              language,
              attemptsRemaining,
              progress: progressData,
            },
          });
        } catch (error) {
          if (!mountedRef.current) return;

          setRecordingError(
            error.message || "Audio submission failed. Please try again."
          );
        } finally {
          if (mountedRef.current) {
            setSubmitting(false);
          }
        }
      };

      recorder.start();
      setRecording(true);

      timerRef.current = setInterval(() => {
        recordingSecondsRef.current += 1;

        if (mountedRef.current) {
          setRecordingSeconds(recordingSecondsRef.current);
        }

        // Limit recordings to 60 seconds.
        if (recordingSecondsRef.current >= 60) {
          const activeRecorder = mediaRecorderRef.current;

          if (activeRecorder?.state === "recording") {
            activeRecorder.stop();
          }
        }
      }, 1000);
    } catch (error) {
      stopMicrophone();

      setRecordingError(
        error.name === "NotAllowedError"
          ? "Microphone permission was denied. Allow microphone access and try again."
          : error.message || "Could not start microphone recording."
      );
    }
  }

  function finishRecording() {
    const recorder = mediaRecorderRef.current;

    if (recorder?.state === "recording") {
      recorder.stop();
    }
  }

  function handleLanguageChange(nextLanguage) {
    if (recording || submitting) return;

    setLanguage(nextLanguage);
    navigate(`/challenge?language=${nextLanguage}`, {
      replace: true,
    });
  }

  const formattedDuration = `${Math.floor(recordingSeconds / 60)
    .toString()
    .padStart(2, "0")}:${(recordingSeconds % 60)
    .toString()
    .padStart(2, "0")}`;

  return (
    <AppShell>
      <div className="pt-3">
        <Link
          to="/dashboard"
          className="inline-flex items-center gap-2 text-sm font-bold text-muted"
        >
          <ArrowLeft size={17} />
          Back to home
        </Link>

        <div className="mt-5 flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-[#678269]">
              Today's challenge
            </p>

            <h1 className="mt-2 text-3xl font-black tracking-tight">
              Make it yours.
            </h1>

            <p className="mt-2 text-sm text-muted">
              Say one sentence using all three words.
            </p>
          </div>

          <span className="flex shrink-0 items-center gap-1 rounded-full bg-[#FFF0C8] px-3 py-2 text-xs font-black text-[#8A5D0D]">
            <Zap size={14} />
            +10 XP
          </span>
        </div>

        {/* Challenge loading and errors */}
        {loadingChallenge && (
          <div className="mt-6 flex items-center gap-3 rounded-2xl border border-line bg-white p-4 text-sm text-muted">
            <LoaderCircle size={18} className="animate-spin" />
            Loading today's words...
          </div>
        )}

        {challengeError && (
          <div
            role="alert"
            className="mt-6 rounded-2xl border border-red-200 bg-red-50 p-4"
          >
            <p className="flex items-center gap-2 font-bold text-red-800">
              <AlertCircle size={18} />
              Could not load the challenge
            </p>

            <p className="mt-2 text-sm text-red-700">
              {challengeError}
            </p>

            <Button
              onClick={() => setLanguage((current) => current)}
              className="mt-3"
            >
              <RefreshCw size={16} />
              Retry
            </Button>
          </div>
        )}

        {/* Real words from FastAPI */}
        <section className="mt-6 rounded-[2rem] bg-forest p-5 text-white sm:p-7">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-white/80">
              Your required words
            </span>

            <span className="rounded-full bg-white/10 px-3 py-1.5 text-xs font-bold">
              {words.length || 3} words
            </span>
          </div>

          {words.length > 0 ? (
            <div className="mt-4 space-y-3">
              {words.map((word, index) => {
                const displayWord = {
                  ...word,
                  english:
                    word.englishWord ??
                    word.english_word ??
                    word.word ??
                    word.english ??
                    `Word ${index + 1}`,
                };

                return (
                  <WordCard
                    key={word.id ?? word.position ?? index}
                    word={displayWord}
                    index={index}
                    onPlayAudio={() => {
                      window.alert(
                        "Pronunciation audio is not connected yet."
                      );
                    }}
                  />
                );
              })}
            </div>
          ) : (
            !loadingChallenge &&
            !challengeError && (
              <p className="mt-4 text-sm text-white/75">
                No words are available for this challenge.
              </p>
            )
          )}
        </section>

        {/* Language and recording */}
        <section className="mt-5 rounded-[2rem] border border-line bg-white p-5 sm:p-7">
          <label
            htmlFor="challenge-language"
            className="text-xs font-black uppercase tracking-wider text-muted"
          >
            Your speaking language
          </label>

          <LanguageSelect
            id="challenge-language"
            value={language}
            onChange={handleLanguageChange}
          />

          <div className="my-6 flex items-center justify-between">
            <div>
              <p className="font-bold">Your attempts</p>
              <p className="mt-1 text-xs text-muted">
                Two tries for today's challenge
              </p>
            </div>

            <div
              className="flex gap-2"
              aria-label={`${attemptsRemaining} attempts remaining`}
            >
              {Array.from({ length: 2 }, (_, index) => (
                <span
                  key={index}
                  className={`size-3 rounded-full ${
                    index < attemptsRemaining
                      ? "bg-forest"
                      : "bg-gray-200"
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="flex flex-col items-center rounded-3xl bg-cream px-4 py-6 text-center">
            <button
              type="button"
              disabled={
                loadingChallenge ||
                Boolean(challengeError) ||
                !challengeId ||
                submitting
              }
              onClick={recording ? finishRecording : startRecording}
              className={`grid size-20 place-items-center rounded-full text-white shadow-lg transition disabled:cursor-not-allowed disabled:opacity-50 ${
                recording
                  ? "animate-pulse bg-[#B84D40]"
                  : "bg-forest"
              }`}
              aria-label={
                recording ? "Finish recording" : "Start recording"
              }
            >
              {submitting ? (
                <LoaderCircle size={31} className="animate-spin" />
              ) : recording ? (
                <Square size={27} fill="currentColor" />
              ) : (
                <Mic size={31} />
              )}
            </button>

            <p className="mt-4 font-black">
              {submitting
                ? "Evaluating your speech..."
                : recording
                  ? "Recording your sentence"
                  : "Ready when you are"}
            </p>

            <p className="mt-1 max-w-xs text-xs leading-5 text-muted">
              {submitting
                ? "Your recording is being evaluated. This may take a moment."
                : recording
                  ? `Tap to stop · ${formattedDuration} / 01:00`
                  : "Allow microphone access, then speak clearly and naturally."}
            </p>
          </div>

          {recordingError && (
            <div
              role="alert"
              className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700"
            >
              {recordingError}
            </div>
          )}
        </section>

        <div className="mt-4 flex items-start gap-2 px-1 text-xs leading-5 text-muted">
          <CircleHelp size={17} className="mt-0.5 shrink-0" />
          <p>
            Your sentence must include all three words. Your score
            and reward will appear after evaluation.
          </p>
        </div>
      </div>
    </AppShell>
  );
}
