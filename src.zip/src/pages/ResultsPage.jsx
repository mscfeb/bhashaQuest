import { Flame, Sparkles, Trophy, Zap } from "lucide-react";
import AppShell from "../components/layout/AppShell";
import Button from "../components/ui/Button";
import StatCard from "../components/ui/StatCard";
import { demoProgress } from "../data/demoData";

export default function ResultsPage() {
  return (
    <AppShell>
      <div className="mx-auto max-w-lg pt-5">
        <section className="relative overflow-hidden rounded-[2rem] bg-forest px-6 py-9 text-center text-white">
          <div className="absolute -right-8 -top-8 size-32 rounded-full bg-white/[0.05]" />
          <div className="absolute -bottom-10 -left-6 size-36 rounded-full bg-white/[0.05]" />
          <div className="relative mx-auto grid size-16 place-items-center rounded-3xl bg-gold text-[#4D3B16]">
            <Trophy size={32} />
          </div>
          <p className="relative mt-5 text-xs font-black uppercase tracking-[0.2em] text-sage">
            Quest completed
          </p>
          <h1 className="relative mt-2 text-3xl font-black">Look at you go!</h1>
          <p className="relative mt-2 text-sm text-white/75">
            You're one step closer to speaking confidently.
          </p>
          <div className="relative mx-auto mt-7 grid size-36 place-items-center rounded-full border-[7px] border-gold/35 bg-white/[0.08]">
            <div>
              <p className="text-5xl font-black">9</p>
              <p className="mt-1 text-sm font-bold text-white/75">out of 10</p>
            </div>
          </div>
          <div className="relative mx-auto mt-5 inline-flex items-center gap-2 rounded-full bg-gold px-5 py-3 font-black text-[#493514]">
            <Zap size={19} /> +10 XP earned
          </div>
        </section>
        <section className="mt-4 rounded-[2rem] border border-line bg-white p-5">
          <div className="flex items-start gap-3">
            <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-sage text-forest">
              <Sparkles size={22} />
            </span>
            <div>
              <h2 className="font-black">Lovely effort!</h2>
              <p className="mt-1 text-sm leading-6 text-muted">
                You used the required words in a meaningful sentence. Keep
                practising to build fluency.
              </p>
            </div>
          </div>
        </section>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <StatCard
            icon={<Flame size={20} />}
            label="Current streak"
            value={`${demoProgress.streak} days`}
            color="bg-[#FFF0C8] text-[#A56B0A]"
          />
          <StatCard
            icon={<Zap size={20} />}
            label="Total XP"
            value={demoProgress.totalXp + 10}
            color="bg-sage text-forest"
          />
        </div>
        <Button to="/dashboard" className="mt-5 w-full">
          Back to dashboard <span aria-hidden="true">→</span>
        </Button>
        <p className="mt-4 text-center text-xs text-muted-light">
          Come back tomorrow for your next daily quest.
        </p>
      </div>
    </AppShell>
  );
}
