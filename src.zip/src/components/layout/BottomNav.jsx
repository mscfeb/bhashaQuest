import { Flame, Home, Mic } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const items = [
  { to: "/dashboard", label: "Home", icon: Home },
  { to: "/challenge", label: "Quest", icon: Mic },
  { to: "/results/demo", label: "Progress", icon: Flame },
];

export default function BottomNav() {
  const location = useLocation();
  return (
    <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-[#FFFDF7]/95 px-3 pb-[max(10px,env(safe-area-inset-bottom))] pt-2 backdrop-blur-lg sm:hidden">
      <div className="mx-auto flex max-w-md items-center justify-around">
        {items.map(({ to, label, icon: Icon }) => {
          const active = location.pathname.startsWith(to);
          return <Link key={label} to={to} className={`flex min-w-16 flex-col items-center gap-1 rounded-xl px-3 py-1.5 text-xs font-bold ${active ? "text-forest" : "text-muted-light"}`}><Icon size={21} />{label}</Link>;
        })}
      </div>
    </nav>
  );
}
