import { Link } from "react-router-dom";

const variants = {
  primary: "bg-forest text-white hover:bg-forest-dark",
  secondary: "border border-line bg-white text-ink hover:bg-cream",
  gold: "bg-gold text-[#332B19] hover:bg-[#EAB03B]",
  soft: "bg-sage text-forest hover:bg-sage-dark",
};

export default function Button({ children, onClick, to, variant = "primary", className = "", type = "button", disabled = false }) {
  const classes = `inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 ${variants[variant]} ${className}`;
  if (to) return <Link to={to} className={classes}>{children}</Link>;
  return <button type={type} onClick={onClick} disabled={disabled} className={classes}>{children}</button>;
}
