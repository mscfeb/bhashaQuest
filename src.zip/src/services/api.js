
const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000"
).replace(/\/$/, "");

/**
 * Shared API request helper.
 * Handles JSON responses, HTTP errors, and connection failures.
 */
async function request(path, options = {}) {
  let response;

  try {
    response = await fetch(`${API_BASE_URL}${path}`, options);
  } catch {
    throw new Error(
      "Cannot connect to the backend. Check that FastAPI is running."
    );
  }

  const contentType = response.headers.get("content-type") || "";

  let data;

  try {
    data = contentType.includes("application/json")
      ? await response.json()
      : await response.text();
  } catch {
    throw new Error("The backend returned an invalid response.");
  }

  if (!response.ok) {
    const message =
      typeof data === "object" && data !== null
        ? data.detail || data.message
        : data;

    throw new Error(
      typeof message === "string"
        ? message
        : `Request failed with status ${response.status}.`
    );
  }

  return data;
}

/**
 * GET /api/challenges/today?language=hi
 * Supported languages: en, hi, kn, te, mr
 */
export function getTodayChallenge(language = "en") {
  const params = new URLSearchParams({ language });

  return request(`/api/challenges/today?${params}`);
}

/**
 * GET /api/progress/today?user_id=<UUID>
 */
export function getTodayProgress(userId) {
  if (!userId) {
    throw new Error("A user ID is required to load progress.");
  }

  const params = new URLSearchParams({ user_id: userId });

  return request(`/api/progress/today?${params}`);
}

/**
 * POST /api/submissions
 * Sends an audio recording as multipart/form-data.
 */
export function submitAudio({
  challengeId,
  language,
  userId,
  audio,
}) {
  if (!challengeId) {
    throw new Error("A challenge ID is required.");
  }

  if (!userId) {
    throw new Error("A user ID is required.");
  }

  if (!(audio instanceof Blob) || audio.size === 0) {
    throw new Error("Please record audio before submitting.");
  }

  const formData = new FormData();

  formData.append("challenge_id", challengeId);
  formData.append("language", language);
  formData.append("user_id", userId);
  formData.append("audio", audio, "recording.webm");

  return request("/api/submissions", {
    method: "POST",
    body: formData,
  });
}
