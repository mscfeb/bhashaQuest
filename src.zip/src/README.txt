Bhasha Quest modular React source.

Copy the contents of this src directory into your frontend/src directory.
Install dependencies:
  npm install react-router-dom lucide-react
  npm install tailwindcss @tailwindcss/vite

Make sure vite.config.js uses react() and tailwindcss() plugins.
Run npm run dev.

This is a UI prototype using demo data. Google sign-in, FastAPI integration,
real audio capture and Gemini evaluation are not connected yet.
